function TestFunction() {
    document.getElementById("demo").innerHTML = "See the magic...!!!";
   }
   